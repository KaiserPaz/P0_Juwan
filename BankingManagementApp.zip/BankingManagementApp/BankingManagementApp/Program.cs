﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankingManagementLib;

namespace BankingManagementApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool Login = true;
            while (Login == true)
            {
                #region Variables
                Security secObj = new Security();
                Transactions tranObj = new Transactions();
                Transactions newTran = new Transactions(); // used for looking at transactions
                Accounts newAcc = new Accounts(); // used for searching, adding, and updating Accounts
                Accounts accObj = new Accounts();

                bool check = false;                
                string v_userName = null;                
                #endregion

                #region Welcome
                Console.WriteLine("Welcome to US Bank \n");

                Console.WriteLine("Which Account Would you Like to Use \n");
                Console.WriteLine("1. Admin");
                Console.WriteLine("2. Customer");
                Console.WriteLine("3. Exit");
                #endregion

                #region Users
                try
                {
                    int userType = Convert.ToInt32(Console.ReadLine());

                    if (userType == 1)
                    {
                        #region Admin 
                        Console.WriteLine("Admin Login \n");
                        Console.WriteLine("Enter Username");
                        string userName = Console.ReadLine();
                        Console.WriteLine("Enter Password");
                        string password = Console.ReadLine();

                        string isValidAdmin = secObj.CheckUserCredentials(userName, password, UserType.Admin);
                        if (isValidAdmin.Contains("Successful"))
                        {
                            Console.Clear();
                            Console.WriteLine("Welcome Admin \n");
                            #region Admin Menu
                            bool continueBanking = true;
                            while (continueBanking == true)
                            {
                                try
                                {
                                    Console.WriteLine("1. Create New Account");
                                    Console.WriteLine("2. View All Accounts");
                                    Console.WriteLine("3. Withdraw");
                                    Console.WriteLine("4. Deposit");
                                    Console.WriteLine("5. Transfer Funds");
                                    Console.WriteLine("6. Disable an Account");
                                    Console.WriteLine("7. Activate an Account");
                                    Console.WriteLine("8. Exit Admin Account");

                                    int choice = Convert.ToInt32(Console.ReadLine());

                                    switch (choice)
                                    {
                                        #region Case 1 Add New Account
                                        case 1:
                                            Console.WriteLine("Enter New Account Number");
                                            newAcc.AccountNumber = Convert.ToInt32(Console.ReadLine());
                                            check = newAcc.checkAccountExist(newAcc.AccountNumber);

                                            if (!check)
                                            {
                                                Console.WriteLine("Enter New Account Name");
                                                newAcc.AccountName = Convert.ToString(Console.ReadLine());

                                                #region Exception
                                                if (newAcc.AccountName.Length < 3)
                                                {
                                                    throw new Exception("Please provide valid name with min 3 char");
                                                }
                                                #endregion

                                                Console.WriteLine("Enter New Account Type");
                                                newAcc.AccountType = Convert.ToString(Console.ReadLine());

                                                #region Exceptions
                                                if (newAcc.AccountType != "Checking" && newAcc.AccountType != "Savings" && newAcc.AccountType != "Loan")
                                                {
                                                    throw new Exception("Sorry Account Must be Either a Checking, a Savings, or a Loan");
                                                }
                                                #endregion

                                                Console.WriteLine("Enter New Account Balance");
                                                newAcc.AccountBalance = Convert.ToDouble(Console.ReadLine());

                                                #region Exception
                                                if (newAcc.AccountBalance < 100)
                                                {
                                                    throw new Exception("Sorry Cannot Open your Account, as Intial Funding Needs to be $100");
                                                }
                                                #endregion

                                                Console.WriteLine("Enter Account Status");
                                                newAcc.AccActive = Console.ReadLine();

                                                #region Exceptions
                                                if (newAcc.AccActive != "Active")
                                                {
                                                    throw new Exception("Sorry Account Must be Either Active, Disabled, or Blocked");
                                                }
                                                if (newAcc.AccActive != "Disabled")
                                                {
                                                    throw new Exception("Sorry Account Must be Either Active, Disabled, or Blocked");
                                                }
                                                if (newAcc.AccActive != "Blocked")
                                                {
                                                    throw new Exception("Sorry Account Must be Either Active, Disabled, or Blocked");
                                                }
                                                #endregion

                                                string result = accObj.AddAccount(newAcc);
                                                Console.WriteLine("New Account Created");
                                                Console.ReadLine();
                                                Console.Clear();
                                            }
                                            else
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Duplicate Account Number \n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 2 Show Accounts
                                        case 2:
                                            Console.Clear();
                                            Console.WriteLine("List of Accounts \n");
                                            List<Accounts> aList = accObj.ListAllAccounts();
                                            int totalAcc = 0;

                                            foreach (var item in aList)
                                            {

                                                Console.WriteLine("Account Number : " + item.AccountNumber);
                                                Console.WriteLine("Account Name : " + item.AccountName);
                                                Console.WriteLine("Account Type : " + item.AccountType);
                                                Console.WriteLine("Account Balance : " + item.AccountBalance);
                                                Console.WriteLine("Account Status : " + item.AccActive);
                                                Console.WriteLine("\n");

                                                Console.WriteLine();

                                                totalAcc = totalAcc + 1;
                                            }
                                            Console.WriteLine("Total Accounts : " + totalAcc + "\n");
                                            break;
                                        #endregion

                                        #region Case 3 Withdraw

                                        case 3:
                                            Console.WriteLine("Enter Account Number You are Withdrawing From ");
                                            newAcc.AccountNumber = Convert.ToInt32(Console.ReadLine());
                                            check = newAcc.checkAccountExist(newAcc.AccountNumber);

                                            if (check)
                                            {
                                                Console.WriteLine("Enter Amount To Withdraw ");
                                                int w_Amount = Convert.ToInt32(Console.ReadLine());

                                                #region Exception
                                                if (w_Amount < 0)
                                                {
                                                    throw new Exception("Sorry Cannot Allow a withdraw of a Negative Amount");
                                                }
                                                #endregion

                                                string withdrawResult = tranObj.Withdraw(newAcc.AccountNumber, newAcc.AccountNumber, w_Amount, UserType.Admin);
                                                Console.Clear();
                                                Console.WriteLine(withdrawResult);
                                                Console.WriteLine("\n");
                                            }
                                            else
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Account is not Found \n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 4 Deposit
                                        case 4:
                                            Console.WriteLine("Enter Account Number You are Depositing in ");
                                            newAcc.AccountNumber = Convert.ToInt32(Console.ReadLine());
                                            check = newAcc.checkAccountExist(newAcc.AccountNumber);

                                            if (check)
                                            {
                                                Console.WriteLine("Enter Amount To Deposit ");
                                                int d_Amount = Convert.ToInt32(Console.ReadLine());

                                                #region Exception
                                                if (d_Amount < 0)
                                                {
                                                    throw new Exception("Sorry Cannot Allow a Deposit of a Negative Amount");
                                                }
                                                #endregion

                                                string depositResult = tranObj.Deposit(newAcc.AccountNumber, newAcc.AccountNumber, d_Amount, UserType.Admin);
                                                Console.Clear();
                                                Console.WriteLine(depositResult);
                                                Console.WriteLine("\n");
                                            }
                                            else
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Account is not Found \n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 5 Transfer
                                        case 5:
                                            Console.WriteLine("Enter Account Number Transfering From ");
                                            newAcc.AccountNumber = Convert.ToInt32(Console.ReadLine());
                                            check = newAcc.checkAccountExist(newAcc.AccountNumber);
                                            if (check)
                                            {
                                                Console.WriteLine("Enter Account Number Transferring To ");
                                                int v_toAccount = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine("Enter Amount To Transfer ");
                                                int v_Amount = Convert.ToInt32(Console.ReadLine());

                                                if (v_Amount < 0)
                                                {
                                                    throw new Exception("Sorry Cannot Allow a Transfer of a Negative Amount");
                                                }
                                                string transferResult = tranObj.Transfer(newAcc.AccountNumber, newAcc.AccountNumber, v_toAccount, v_Amount, UserType.Admin);
                                                Console.Clear();

                                                Console.WriteLine(transferResult);
                                                Console.WriteLine("\n");
                                            }
                                            else
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Account is not Found \n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 6 Disable Account
                                        case 6:
                                            Console.WriteLine("Enter Account Number to Disable");
                                            int d_AccountNumber = Convert.ToInt32(Console.ReadLine());
                                            check = accObj.checkAccountExist(newAcc.AccountNumber);
                                            if (!check)
                                            {

                                                string updateResult = accObj.DisableAccount(d_AccountNumber);
                                                Console.Clear();
                                                Console.WriteLine(updateResult);
                                                Console.WriteLine("\n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 7 Activating Account
                                        case 7:
                                            Console.WriteLine("Which Account Number Should be Activated");
                                            int a_AccountNumber = Convert.ToInt32(Console.ReadLine());
                                            check = accObj.checkAccountExist(newAcc.AccountNumber);
                                            if (!check)
                                            {
                                                string updateResult = accObj.ActivateAccount(a_AccountNumber);
                                                Console.Clear();
                                                Console.WriteLine(updateResult);
                                                Console.WriteLine("\n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 8 Exit Admin
                                        case 8:
                                            Console.WriteLine("Thank you Admin");
                                            continueBanking = false;
                                            Console.ReadLine();
                                            break;
                                        #endregion

                                        default:
                                            Console.Clear();
                                            Console.WriteLine("Not Optional Choice \n");
                                            break;
                                    }
                                }
                                catch (Exception es)
                                {
                                    Console.WriteLine(es.Message);
                                    Console.ReadLine();
                                    Console.Clear();
                                }
                                finally
                                {

                                }

                            }
                            #endregion
                        }
                        else
                        {
                            Console.WriteLine("Incorrect Admin Credentials");
                            Console.ReadLine();
                        }
                        #endregion
                    }
                    else if (userType == 2)
                    {
                        #region Customer
                        Console.WriteLine("Customer Login \n");
                        Console.WriteLine("Enter Username");
                        string uName = Console.ReadLine();
                        Console.WriteLine("Enter Password");
                        string pwd = Console.ReadLine();

                        string isValidCustomer = secObj.CheckUserCredentials(uName, pwd, UserType.Customer);
                        if (isValidCustomer.Contains("Successful"))
                        {
                            Console.Clear();
                            Console.WriteLine("Welcome Customer \n");
                            #region Customer Menu
                            bool continueBanking = true;
                            while (continueBanking == true)
                            {
                                try
                                {
                                    Console.WriteLine("1. Check Balance");
                                    Console.WriteLine("2. Withdraw");
                                    Console.WriteLine("3. Deposit");
                                    Console.WriteLine("4. Transfer");
                                    Console.WriteLine("5. View Last 10 Transactions");
                                    Console.WriteLine("6. Change Password");
                                    Console.WriteLine("7. Exit Customer");

                                    int choice = Convert.ToInt32(Console.ReadLine());

                                    switch (choice)
                                    {
                                        #region Case 1 View Balance
                                        case 1:
                                            v_userName = uName;
                                            List<Accounts> aList = accObj.CheckBalance(v_userName);
                                            foreach (var item in aList)
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Your Current Balance is : " + item.AccountBalance);
                                                Console.WriteLine("\n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 2 Withdraw
                                        case 2:
                                            v_userName = uName;
                                            int p_AccountNumber = tranObj.GetANumber(v_userName);
                                            Console.WriteLine("Enter Amount You would Like to Withdraw?");
                                            int w_Amount = Convert.ToInt32(Console.ReadLine());

                                            #region Exception
                                            if (w_Amount < 0)
                                            {
                                                throw new Exception("Sorry Cannot Allow a withdraw of a Negative Amount");
                                            }
                                            #endregion

                                            string withdrawResult = tranObj.userWithdraw(p_AccountNumber, v_userName, w_Amount, UserType.Customer);
                                            Console.Clear();
                                            Console.WriteLine(withdrawResult);
                                            Console.WriteLine("\n");
                                            break;
                                        #endregion

                                        #region Case 3 Deposit
                                        case 3:
                                            v_userName = uName;
                                            int v_AccountNumber = tranObj.GetANumber(v_userName);
                                            Console.WriteLine("Enter Amount You would Like to Deposit?");
                                            int d_Amount = Convert.ToInt32(Console.ReadLine());

                                            #region Exception
                                            if (d_Amount < 0)
                                            {
                                                throw new Exception("Sorry Cannot Allow a Deposit of a Negative Amount");
                                            }
                                            #endregion

                                            string depositResult = tranObj.userDeposit(v_AccountNumber, v_userName, d_Amount, UserType.Customer);
                                            Console.Clear();
                                            Console.WriteLine(depositResult);
                                            Console.WriteLine("\n");
                                            break;
                                        #endregion

                                        #region Case 4 Transfer
                                        case 4:
                                            v_userName = uName;
                                            int t_AccountNumber = tranObj.GetANumber(v_userName);
                                            Console.WriteLine("Enter Account Number Transferring To ");
                                            int v_toAccount = Convert.ToInt32(Console.ReadLine());
                                            newAcc.AccountNumber = v_toAccount;
                                            check = newAcc.checkAccountExist(newAcc.AccountNumber);
                                            if (check)
                                            {
                                                Console.WriteLine("Enter Amount To Transfer ");
                                                int v_Amount = Convert.ToInt32(Console.ReadLine());

                                                if (v_Amount < 0)
                                                {
                                                    throw new Exception("Sorry Cannot Allow a Transfer of a Negative Amount");
                                                }
                                                string transferResult = tranObj.userTransfer(t_AccountNumber, v_toAccount, v_Amount, UserType.Admin);
                                                Console.Clear();

                                                Console.WriteLine(transferResult);
                                                Console.WriteLine("\n");
                                            }
                                            else
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Account is not Found \n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 5 Last 10 Transactions
                                        case 5:
                                            try
                                            {
                                                v_userName = uName;
                                                Console.WriteLine("The Last 10 Transactions \n");
                                                List<Transactions> TranList = tranObj.TenTransactions(v_userName);
                                                foreach (var item in TranList)
                                                {

                                                    Console.WriteLine("Transaction Number : " + item.ANumber);
                                                    Console.WriteLine("Transaction Date : " + item.calender);
                                                    Console.WriteLine("Transaction From : " + item.fromAccount);
                                                    Console.WriteLine("Transaction To : " + item.toAccount);
                                                    Console.WriteLine("Transaction Amount : " + item.Amount);
                                                    Console.WriteLine("Transaction By : " + item.TransferredBy);
                                                    Console.WriteLine("\n");
                                                }

                                            }
                                            catch (Exception es)
                                            {
                                                Console.Clear();
                                                Console.WriteLine(es.Message);
                                                Console.WriteLine("\n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 6 Password Change
                                        case 6:
                                            v_userName = uName;
                                            Console.WriteLine("Enter New Password");
                                            string p_Password = Console.ReadLine();
                                            check = accObj.checkAccountExist(newAcc.AccountNumber);
                                            if (!check)
                                            {
                                                string updateResult = secObj.changePassword(p_Password, v_userName);
                                                Console.Clear();
                                                Console.WriteLine(updateResult);
                                                Console.WriteLine("\n");
                                            }
                                            break;
                                        #endregion

                                        #region Case 7 Exit Customer
                                        case 7:
                                            Console.WriteLine("Thank you Customer");
                                            continueBanking = false;
                                            Console.ReadLine();
                                            break;
                                        #endregion

                                        default:
                                            Console.WriteLine("Not optional Choice");
                                            break;
                                    }
                                }
                                catch (Exception es)
                                {
                                    Console.WriteLine(es.Message);
                                    Console.ReadLine();
                                    Console.Clear();
                                }

                            }
                            #endregion
                        }
                        else
                        {
                            Console.WriteLine(isValidCustomer);
                            Console.ReadLine();
                        }
                        #endregion
                    }
                    else if (userType == 3)
                    {
                        #region Exit
                        Console.Clear();
                        Console.WriteLine("GoodBye \n");
                        Console.ReadLine();
                        Login = false;
                        #endregion
                    }
                    else
                    {
                        Console.WriteLine("Invalid Option \n");
                        Console.ReadLine();
                    }
                    Console.Clear();

                }
                catch (Exception es)
                {
                    Console.WriteLine(es.Message);
                    Console.ReadLine();
                    Console.Clear();
                }
                #endregion
            }
        }
    }
}
