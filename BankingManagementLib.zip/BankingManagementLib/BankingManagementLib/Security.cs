﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BankingManagementLib
{
    public enum UserType
    {
        Admin,
        Customer
    }
    public class Security
    {

        #region properties
        public string userName { get; set; }
        public string userPassword { get; set; }
        public string accountStatus { get; set; }
        public int attempts { get; set; }
        #endregion

        #region Login
        public string CheckUserCredentials(string userName, string password, UserType p_uType)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;user id=sa;password=Password1234");

            SqlCommand cmd;

            if (p_uType == UserType.Admin)
            {
                cmd = new SqlCommand("select count(*) from AdminLogin where userName=@uName and password=@pwd", con);
            }
            else
            {
                cmd = new SqlCommand("select count(*) from CustomerLogin where userName=@uName and password=@pwd", con);
            }

            cmd.Parameters.AddWithValue("@uName", userName);
            cmd.Parameters.AddWithValue("@pwd", password);
            con.Open();
            int loginResult = (int)cmd.ExecuteScalar();
            con.Close();

            if (p_uType == UserType.Customer)
            {
                SqlCommand cmdAddAttempt = new SqlCommand("select accountStatus, attempts from CustomerLogin where userName=@uName", con);
                cmdAddAttempt.Parameters.AddWithValue("@uName", userName);
                con.Open();

                SqlDataReader readUser = cmdAddAttempt.ExecuteReader();
                if (readUser.Read())
                {
                    string status = readUser[0].ToString();
                    int attempts = (int)readUser[1];
                    readUser.Close();

                    if (status == "Blocked")
                    {
                        return "Account is Blocked, Please Contact Admin Support";
                    }

                    if (loginResult == 1 && status == "Active")
                    {
                        return "Login Successful";
                    }
                    else
                    {
                        SqlCommand updateAccount;
                        if (attempts == 3)
                        {
                            updateAccount = new SqlCommand("update CustomerLogin set accountStatus = 'Blocked' where userName=@uName", con);
                        }
                        else
                        {
                            updateAccount = new SqlCommand("update CustomerLogin set attempts = attempts+1 where userName=@uName", con);
                        }

                        updateAccount.Parameters.AddWithValue("@uName", userName);
                        updateAccount.ExecuteNonQuery();

                        return "Login Failed for User " + userName;
                    }

                }
                con.Close();
                return "Incorrect Username or Password";
            }
            else
            {
                if (loginResult == 1)
                {
                    return "Login Successful";
                }
                else
                {
                    return "Login Failed";
                }

            }

        }

        public string changePassword(string p_Password, string p_userName)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;user id=sa;password=Password1234");

            SqlCommand cmdChangePassword = new SqlCommand("update CustomerLogin set password = @password where userName = @userName", con);
            cmdChangePassword.Parameters.AddWithValue("@password", p_Password);
            cmdChangePassword.Parameters.AddWithValue("@userName", p_userName);
            con.Open();
            int updateResult = cmdChangePassword.ExecuteNonQuery();
            con.Close();

            if (updateResult > 0)
            {
                return "Password has been Changed";
            }
            return "Password not Changed";                       
        }
        #endregion
    }
}
