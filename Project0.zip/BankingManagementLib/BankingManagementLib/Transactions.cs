﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace BankingManagementLib
{
    public class Transactions
    {
        #region Properties
        public int ANumber { get; set; }
        public DateTime calender { get; set; }
        public int fromAccount { get; set; }
        public int toAccount { get; set; }
        public int Amount { get; set; }
        public string TransferredBy { get; set; }
        #endregion

        #region Transactions
        public string Transfer(int p_AccountNumber, int p_fromAccount, int p_toAccount, int p_Amount, UserType p_userType)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;integrated security=true");
            SqlCommand cmdFrom = new SqlCommand("update Accounts set AccountBalance = AccountBalance - @Amount where AccountNumber = @fromAccount", con);
            cmdFrom.Parameters.AddWithValue("@Amount", p_Amount);
            cmdFrom.Parameters.AddWithValue("@fromAccount", p_fromAccount);

            SqlCommand cmdTo = new SqlCommand("update Accounts set AccountBalance = AccountBalance + @Amount where AccountNumber = @toAccount", con);
            cmdTo.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTo.Parameters.AddWithValue("@toAccount", p_toAccount);

            SqlCommand cmdTransaction = new SqlCommand("insert into Transactions(calender,toAccount,Amount,transferredBy) values(GETDATE(),@fromAccount,@toAccount,@Amount,@uType)", con);            
            cmdTransaction.Parameters.AddWithValue("@fromAccount", p_AccountNumber);
            cmdTransaction.Parameters.AddWithValue("@toAccount", p_toAccount);
            cmdTransaction.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTransaction.Parameters.AddWithValue("@uType", p_userType);

            con.Open();
            cmdFrom.ExecuteNonQuery();
            cmdTo.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Transfer Complete";
        }

        public string userTransfer(int p_AccountNumber, int p_toAccount, int p_Amount, UserType p_userType)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;integrated security=true");
            SqlCommand cmdFrom = new SqlCommand("update Accounts set AccountBalance = AccountBalance - @Amount where AccountNumber = @fromAccount", con);
            cmdFrom.Parameters.AddWithValue("@Amount", p_Amount);
            cmdFrom.Parameters.AddWithValue("@fromAccount", p_AccountNumber);

            SqlCommand cmdTo = new SqlCommand("update Accounts set AccountBalance = AccountBalance + @Amount where AccountNumber = @toAccount", con);
            cmdTo.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTo.Parameters.AddWithValue("@toAccount", p_toAccount);

            SqlCommand cmdTransaction = new SqlCommand("insert into Transactions(calender,fromAccount,toAccount,Amount,transferredBy) values(GETDATE(),@fromAccount,@toAccount,@Amount,@uType)", con);            
            cmdTransaction.Parameters.AddWithValue("@fromAccount", p_AccountNumber);
            cmdTransaction.Parameters.AddWithValue("@toAccount", p_toAccount);
            cmdTransaction.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTransaction.Parameters.AddWithValue("@uType", p_userType);

            con.Open();
            cmdFrom.ExecuteNonQuery();
            cmdTo.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Transfer Complete";
        }

        public string Withdraw(int p_AccountNumber, int p_toAccount, int p_Amount, UserType p_userType)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;integrated security=true");
            SqlCommand cmdFrom = new SqlCommand("update Accounts set AccountBalance = AccountBalance - @Amount where AccountNumber = @fromAccount", con);
            cmdFrom.Parameters.AddWithValue("@Amount", p_Amount);
            cmdFrom.Parameters.AddWithValue("@fromAccount", p_toAccount);


            SqlCommand cmdTransaction = new SqlCommand("insert into Transactions(calender,fromAccount,Amount,transferredBy) values(GETDATE(),@fromAccount,@Amount,@transferredBy)", con);
            
            cmdTransaction.Parameters.AddWithValue("@fromAccount", p_toAccount);
            cmdTransaction.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTransaction.Parameters.AddWithValue("@transferredBy", p_userType);

            con.Open();
            cmdFrom.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Withdraw Complete";
        }

        public string userWithdraw(int p_AccountNumber, string p_userName, int p_Amount, UserType p_userType)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;integrated security=true");
            SqlCommand cmdFrom = new SqlCommand("update Accounts set AccountBalance = AccountBalance - @Amount from Accounts right join CustomerLogin on CustomerLogin.AccountNumber=Accounts.AccountNumber where userName = @userName;", con);
            cmdFrom.Parameters.AddWithValue("@Amount", p_Amount);
            cmdFrom.Parameters.AddWithValue("@userName", p_userName);


            SqlCommand cmdTransaction = new SqlCommand("insert into Transactions(calender,toAccount,Amount,transferredBy) values(GETDATE(),@toAccount,@Amount,@transferredBy)", con);
            cmdTransaction.Parameters.AddWithValue("@toAccount", p_AccountNumber);            
            cmdTransaction.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTransaction.Parameters.AddWithValue("@transferredBy", p_userType);

            con.Open();            
            cmdFrom.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Withdraw Complete";
        }

        public string Deposit(int p_AccountNumber, int p_fromAccount, int p_Amount, UserType p_userType)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;integrated security=true");
            SqlCommand cmdTo = new SqlCommand("update Accounts set AccountBalance = AccountBalance + @Amount where AccountNumber = @toAccount", con);
            cmdTo.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTo.Parameters.AddWithValue("@toAccount", p_fromAccount);

            SqlCommand cmdTransaction = new SqlCommand("insert into Transactions(calender,toAccount,Amount,transferredBy) values(GETDATE(),@toAccount,@Amount,@transferredBy)", con);
            cmdTransaction.Parameters.AddWithValue("@toAccount", p_fromAccount);
            cmdTransaction.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTransaction.Parameters.AddWithValue("@transferredBy", p_userType);

            con.Open();
            cmdTo.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Deposit Complete";
        }

        public int GetANumber(string p_userName)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;integrated security=true");
            SqlCommand cmdGetANum = new SqlCommand("select CustomerLogin.AccountNumber from Accounts full outer join CustomerLogin on CustomerLogin.AccountNumber=Accounts.AccountNumber where userName = @userName", con);
            cmdGetANum.Parameters.AddWithValue("@userName", p_userName);
            
            
            con.Open();
            int AccountNumber =(int)cmdGetANum.ExecuteScalar();            
            con.Close();

            return AccountNumber;
        }
        public string userDeposit(int p_AccountNumber, string p_userName, int p_Amount, UserType p_userType)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;integrated security=true");
            SqlCommand cmdTo = new SqlCommand("update Accounts set AccountBalance = AccountBalance + @Amount  from Accounts full outer join CustomerLogin on CustomerLogin.AccountNumber=Accounts.AccountNumber where userName = @userName", con);
            cmdTo.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTo.Parameters.AddWithValue("@userName", p_userName);

            SqlCommand cmdTransaction = new SqlCommand("insert into Transactions(calender,fromAccount,Amount,transferredBy) values(GETDATE(),@fromAccount,@Amount,@transferredBy)", con);
             cmdTransaction.Parameters.AddWithValue("@fromAccount", p_AccountNumber);
            cmdTransaction.Parameters.AddWithValue("@Amount", p_Amount);
            cmdTransaction.Parameters.AddWithValue("@transferredBy", p_userType);

            con.Open();
            cmdTo.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Deposit Complete";
        }
        public List<Transactions> TenTransactions(string v_userName)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;user id=sa;password=Password1234");
            SqlCommand cmdLastTrans = new SqlCommand("select top 10 * from Transactions left join CustomerLogin on Transactions.fromAccount = CustomerLogin.AccountNumber where userName = @userName order by calender desc, trNum", con);
            cmdLastTrans.Parameters.AddWithValue("@userName", v_userName);
            con.Open();
            SqlDataReader readTran = cmdLastTrans.ExecuteReader();
            List<Transactions> TranList = new List<Transactions>();
            while (readTran.Read())
            {
                TranList.Add(new Transactions()
                {
                    ANumber = (int)readTran[0],
                    calender = (DateTime)readTran[1],
                    fromAccount = (readTran[2]as int? ?? default(int)),
                    toAccount = (readTran[3]as int? ?? default(int)),
                    Amount = (int)readTran[4],
                    TransferredBy = readTran[5].ToString(),
                }); 
            }
            readTran.Close();
            con.Close();
            return TranList;

        }
        #endregion
    }
}
