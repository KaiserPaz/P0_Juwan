﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BankingManagementLib
{
    public class Accounts
    {
        SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;user id=sa;password=Password1234");

        #region properties
        public int AccountNumber { get; set; }
        public string AccountName { get; set; }
        public string AccountType { get; set; }
        public double AccountBalance { get; set; }
        public string AccActive { get; set; }

        #endregion               

        #region Account settings
        public string AddAccount(Accounts p_accObj)
        {
            SqlCommand cmdNewAccount = new SqlCommand("insert into Accounts values(@AccountNumber,@AccountName,@AccountType,@AccountBalance,@AccActive)", con);
            cmdNewAccount.Parameters.AddWithValue("@AccountNumber", p_accObj.AccountNumber);
            cmdNewAccount.Parameters.AddWithValue("@AccountName", p_accObj.AccountName);
            cmdNewAccount.Parameters.AddWithValue("@AccountType", p_accObj.AccountType);
            cmdNewAccount.Parameters.AddWithValue("@AccountBalance", p_accObj.AccountBalance);
            cmdNewAccount.Parameters.AddWithValue("@AccActive", p_accObj.AccActive);
            con.Open();
            int recordsAffected = cmdNewAccount.ExecuteNonQuery(); //this method returns number of records affected in datbase
            con.Close();
            return "Account Added Successfully";
        }
        public bool checkAccountExist(int p_accNo)
        {
            SqlCommand cmdCheck = new SqlCommand("select count(*) from Accounts where AccountNumber = @AccountNumber", con);
            cmdCheck.Parameters.AddWithValue("@AccountNumber", p_accNo);

            con.Open();
            int count = (int)cmdCheck.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
        public string DisableAccount(int p_AccountNumber)
        {
            SqlCommand cmdDisableAccount = new SqlCommand("update Accounts set AccActive = 'Disabled' where AccountNumber = @AccountNumber; update CustomerLogin set accountStatus = 'Disabled' where AccountNumber = @AccountNumber", con);
            cmdDisableAccount.Parameters.AddWithValue("@AccountNumber", p_AccountNumber);
            con.Open();
            int updateResult = cmdDisableAccount.ExecuteNonQuery();
            con.Close();

            if (updateResult == 0)
            {
                return "Account Not Found";
            }
            return "Account Disabled Successfully";

        }
        public string ActivateAccount(int p_AccountNumber)
        {
            SqlCommand cmdActivateAccount = new SqlCommand("update Accounts set AccActive = 'Active' where AccountNumber = @AccountNumber; update CustomerLogin set accountStatus = 'Active' where AccountNumber = @AccountNumber; update CustomerLogin set attempts = 0 where AccountNumber = @AccountNumber", con);
            cmdActivateAccount.Parameters.AddWithValue("@AccountNumber", p_AccountNumber);
            con.Open();
            int updateResult = cmdActivateAccount.ExecuteNonQuery();
            con.Close();

            if (updateResult > 0)
            {
                return "Account has been Activated";
            }
            return "Account is not Found";
        }
        public List<Accounts> ListAllAccounts()
        {
            SqlCommand cmdAllAccounts = new SqlCommand("select * from Accounts order by AccountNumber", con);
            con.Open();
            SqlDataReader readAcc = cmdAllAccounts.ExecuteReader();

            List<Accounts> accList = new List<Accounts>();
            while (readAcc.Read())
            {
                accList.Add(new Accounts()
                {
                    AccountNumber = (int)readAcc[0],
                    AccountName = readAcc[1].ToString(),
                    AccountType = readAcc[2].ToString(),
                    AccountBalance = (int)readAcc[3],
                    AccActive = readAcc[4].ToString()
                });
            }
            readAcc.Close();
            con.Close();
            return accList;
        }
        public List<Accounts> CheckBalance(string p_userName)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=BankingManagementDB;user id=sa;password=Password1234");
            SqlCommand cmdCheckBalance = new SqlCommand("SELECT CustomerLogin.userName, Accounts.AccountType, Accounts.AccountBalance FROM Accounts right JOIN CustomerLogin ON CustomerLogin.AccountNumber=Accounts.AccountNumber where userName = @userName", con);
            cmdCheckBalance.Parameters.AddWithValue("@userName", p_userName);
            con.Open();
            SqlDataReader readBal = cmdCheckBalance.ExecuteReader();
            List<Accounts> BalList = new List<Accounts>();
            while (readBal.Read())
            {
                BalList.Add(new Accounts()
                {                    
                    AccountBalance = (int)readBal[2],
                });
            }
            readBal.Close();
            con.Close();
            return BalList;

        }
        
        #endregion
    }
}
